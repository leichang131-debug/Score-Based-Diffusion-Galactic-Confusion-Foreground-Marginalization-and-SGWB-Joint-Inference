set -euo pipefail
base=/home/disk/sgwb-research/fullcov-fig8-20261121
cd "$base"
exec 9>logs/td-prep.lock
flock -n 9
export JAX_PLATFORMS=cpu MPLBACKEND=Agg MPLCONFIGDIR="$base/matplotlib"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export P="$base/.venv/bin/python" LOGS="$base/logs"
cd external/taiji-sgwb-time-domain
export PYTHONPATH="$PWD"
driver=scripts/astro/ch33_sw10_fullxyz_20260531.py
export TABLES=scripts/astro/ch32_precompute_response_noise_tables_20260521.py
date -u
bench() {
    local cfg="$1" seed="$2" case_id="$3" bundle
    bundle=$(find "data/ch33_sw10_fullxyz_20260531/$cfg/bundles" -name "*seed${seed}*bundle.h5" -print -quit)
    test -n "$bundle"
    "$P" -u infer.py check --case "$case_id" --bundle "$bundle" --output "$base/td-check/$case_id" > "$LOGS/check-$case_id.txt" 2>&1
    "$P" -u "$base/bench-likelihood.py" "$case_id" "$bundle" > "$LOGS/benchmark-$case_id-cpu.json"
}
bench fd_equal 2026060255 fit_079
"$P" -u "$driver" build-td-equal --seed 2026069815 --orbit-chunks 360 --log-omega-0=-11.5 --max-parallel 4 > "$LOGS/td-equal-build.txt" 2>&1 &
equal_pid=$!
seq 0 30 330 | xargs -P 6 -I % bash -c 'start=$1; MODE=chunk START_SEG=$start END_SEG=$((start+30)) "$P" -u "$TABLES" > "$LOGS/response-$start.txt" 2>&1' response % &
response_pid=$!
equal_rc=0
wait "$equal_pid" || equal_rc=$?
if [ "$equal_rc" = 0 ]; then
    bench td_equal 2026069815 fit_081 || echo "Equal-arm benchmark failed"
else
    echo "Equal-arm input build failed with status $equal_rc"
fi
wait "$response_pid"
MODE=combine "$P" -u "$TABLES" > "$LOGS/response-combine.txt" 2>&1
"$P" -u "$driver" build-td-unequal --seed 2026069415 --orbit-chunks 360 --log-omega-0=-11.5 --max-parallel 4 > "$LOGS/td-unequal-build.txt" 2>&1
bench td_unequal 2026069415 fit_083
date -u
