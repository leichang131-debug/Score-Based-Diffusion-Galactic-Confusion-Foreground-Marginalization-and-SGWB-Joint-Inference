"""Validate and fit the author's FD equal-arm Figure 8 input."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

import dill
import h5py
import numpy as np

base = Path(__file__).resolve().parent
root = base / "external/taiji-sgwb-time-domain"
logs = base / "logs"
os.chdir(root)
sys.path.insert(0, str(root))
import infer

python = sys.executable
seed = "20261017"
case = "fit_079"
bundle, = (root / "data/ch33_sw10_fullxyz_20260531/fd_equal/bundles").glob("*seed2026060255*bundle.h5")
common = [python, "-u", "infer.py"]
run = common + ["run", "--case", case, "--bundle", str(bundle), "--seed", seed]
report = {"case": case, "backend": os.environ["JAX_PLATFORMS"], "sampler_seed": int(seed)}
report_path = logs / "fd-campaign.json"


def save():
    temp = report_path.with_suffix(".tmp")
    temp.write_text(json.dumps(report, indent=2) + "\n")
    temp.replace(report_path)


def execute(command, name, interrupt=False):
    log = logs / f"{name}.txt"
    start = time.monotonic()
    report[name] = {"command": command, "started_utc_epoch": time.time()}
    save()
    with log.open("wb") as file:
        process = subprocess.Popen(command, stdout=file, stderr=subprocess.STDOUT)
        report[name]["pid"] = process.pid
        save()
        if interrupt:
            while process.poll() is None:
                if b"ncall:" in log.read_bytes():
                    process.send_signal(signal.SIGTERM)
                    break
                if time.monotonic() - start > 300:
                    process.terminate()
                    process.wait()
                    raise RuntimeError("No pilot progress marker within five minutes")
                time.sleep(0.2)
        code = process.wait()
    report[name].update(returncode=code, wall_seconds=time.monotonic() - start)
    save()
    if code != (130 if interrupt else 0):
        raise RuntimeError(f"{name} exited with {code}: {log}")
    return log


def results(outdir):
    directory = outdir / case
    with (directory / f"{case}_dynesty.pickle").open("rb") as stream:
        result = dill.load(stream)
    with h5py.File(directory / "posterior.h5") as file:
        trace = file["pe/trace"][:]
        if trace.shape[1] != 10 or not len(trace) or not np.isfinite(trace).all():
            raise ValueError("Invalid completed posterior")
        return {"likelihood_calls": int(np.sum(result.ncall)),
                "nested_iterations": int(result.niter), "samples": len(trace),
                "log_evidence": float(file["pe/evidence"][()]),
                "log_evidence_error": float(file["pe/evidence_err"][()]),
                "weights_ess": float(1. / np.sum(result.importance_weights() ** 2))}


def main():
    with bundle.open("rb") as stream:
        report["input_sha256"] = hashlib.file_digest(stream, "sha256").hexdigest()
    execute(common + ["check", "--case", case, "--bundle", str(bundle), "--output", str(base / "check")], "check")
    pilot_out = base / "pilot"
    pilot = run + ["--output", str(pilot_out), "--nlive", "48", "--dlogz", "8", "--walks", "16"]
    execute(pilot, "pilot-interrupt", interrupt=True)
    checkpoint = pilot_out / case / f"{case}_resume.pickle"
    with checkpoint.open("rb") as stream:
        state = dill.load(stream)
    report["pilot_checkpoint"] = {"iteration": int(state.it), "likelihood_calls": int(state.ncall)}
    if state.it <= 1:
        raise RuntimeError("The pilot checkpoint did not contain sampling progress")
    save()
    resumed = execute(pilot + ["--resume"], "pilot-resume")
    if "Resume file successfully loaded." not in resumed.read_text(errors="replace"):
        raise RuntimeError("Bilby did not confirm loading the pilot checkpoint")
    report["pilot_result"] = results(pilot_out)
    if report["pilot_result"]["likelihood_calls"] <= report["pilot_checkpoint"]["likelihood_calls"]:
        raise RuntimeError("Pilot did not advance after restoration")
    save()
    production = base / "production"
    execute(run + ["--output", str(production)], "production")
    report["production_result"] = results(production)
    report["peak_child_rss_kib"] = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    report["status"] = "complete"
    save()


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        report.update(status="failed", error=str(error))
        save()
        raise
