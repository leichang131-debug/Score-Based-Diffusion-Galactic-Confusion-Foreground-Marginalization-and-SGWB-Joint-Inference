import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import dill
import h5py
import numpy as np

base = Path.cwd()
root = base / "external/taiji-sgwb-time-domain"
case = "fit_081"
bundle, = (root / "data/ch33_sw10_fullxyz_20260531/td_equal/bundles/om0m11p5").glob("*seed2026069815*bundle.h5")
check = json.loads((base / "td-check/fit_081/likelihood_verification.json").read_text())
if check["status"] != "PASS" or not any(x["id"] == case and x["pass"] for x in check["checks"]):
    raise RuntimeError("fit_081 production input has not passed validation")
out = base / "production"
report = base / "logs/fit_081-campaign.json"
if report.exists() or (out / case).exists():
    raise FileExistsError("An existing production run requires explicit inspection")
with bundle.open("rb") as stream:
    digest = hashlib.file_digest(stream, "sha256").hexdigest()
seed = 20261017
runner = 'import os,runpy,sys; sys.path.append(os.environ["CUDA_SITE"]); sys.argv[0]="infer.py"; runpy.run_path("infer.py",run_name="__main__")'
command = [sys.executable, "-u", "-c", runner, "run", "--case", case, "--bundle", str(bundle), "--seed", str(seed), "--output", str(out)]
state = {"case":case,"status":"starting","backend":"cuda","sampler_seed":seed,"input_sha256":digest,
         "command":command,"started_utc_epoch":time.time(),"settings":{"nlive":1000,"dlogz":0.1,"walks":64}}
def save():
    temp = report.with_suffix(".tmp")
    temp.write_text(json.dumps(state, indent=2) + "\n")
    temp.replace(report)
save()
start = time.monotonic()
try:
    with (base / "logs/fit_081-production.txt").open("x") as log:
        process = subprocess.Popen(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
        state.update(status="running", pid=process.pid)
        save()
        code = process.wait()
    state.update(returncode=code, wall_seconds=time.monotonic()-start)
    if code == 130:
        state["status"] = "paused"
        save()
        raise SystemExit(code)
    if code:
        raise RuntimeError(f"Sampler exited with {code}")
    with (out / case / f"{case}_dynesty.pickle").open("rb") as stream:
        dynesty = dill.load(stream)
    with h5py.File(out / case / "posterior.h5") as file:
        trace = file["pe/trace"][:]
        if trace.ndim != 2 or trace.shape[1] != 10 or not len(trace) or not np.isfinite(trace).all():
            raise ValueError("Invalid ten-parameter posterior")
        state["result"] = {"likelihood_calls":int(np.sum(dynesty.ncall)), "nested_iterations":int(dynesty.niter),
                           "samples":len(trace), "log_evidence":float(file["pe/evidence"][()]),
                           "log_evidence_error":float(file["pe/evidence_err"][()])}
    state["status"] = "complete"
    save()
except Exception as error:
    state.update(status="failed", error=str(error), wall_seconds=time.monotonic()-start)
    save()
    raise
