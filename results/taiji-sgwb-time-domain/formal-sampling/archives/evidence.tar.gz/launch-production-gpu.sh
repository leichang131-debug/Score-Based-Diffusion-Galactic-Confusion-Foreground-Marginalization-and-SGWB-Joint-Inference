set -euo pipefail
base=/home/disk/sgwb-research/fullcov-fig8-20261121
cd "$base"
exec 9>logs/fd-campaign.lock
flock -w 60 9
test ! -e production/fit_079/posterior.h5
export JAX_PLATFORMS=cuda XLA_PYTHON_CLIENT_PREALLOCATE=false
export CUDA_SITE=/home/disk/sgwb-research/environments/route-b-linux-gpu/lib/python3.12/site-packages
export MPLBACKEND=Agg MPLCONFIGDIR="$base/matplotlib"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
free=$(nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits | head -1)
test "$free" -ge 16384
exec nice -n 5 "$base/.venv/bin/python" -u production-gpu.py "$@"
