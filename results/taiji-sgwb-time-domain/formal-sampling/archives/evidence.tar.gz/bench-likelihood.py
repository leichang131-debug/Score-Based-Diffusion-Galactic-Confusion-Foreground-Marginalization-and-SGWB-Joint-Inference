"""Time the unchanged upstream likelihood on a validated production bundle."""
import argparse
import json
from pathlib import Path
import time

import infer
import jax
import jax.numpy as jnp
import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("case")
parser.add_argument("bundle", type=Path)
parser.add_argument("--calls", type=int, default=120)
args = parser.parse_args()
record = infer.record_for(args.case)
arrays, attrs, reference = infer.load_input(record, args.bundle)
truth = infer.stage_truth(arrays["parameters_true"], record["fit_names"])
start = time.perf_counter()
likelihood = infer.make_loglike(arrays, attrs, "jax")
truth_value = float(likelihood(jnp.asarray(truth)))
startup = time.perf_counter() - start
if not np.isfinite(truth_value) or abs(truth_value-reference) > infer.likelihood_tolerance(record):
    raise ValueError(f"Production likelihood mismatch: {truth_value} vs {reference}")
rng = np.random.default_rng(20261017)
points = truth + rng.normal(0, .01, size=(args.calls, len(truth)))
durations = []
for point in points:
    start = time.perf_counter()
    value = float(likelihood(jnp.asarray(point)))
    durations.append(time.perf_counter() - start)
    if not np.isfinite(value):
        raise ValueError("Nonfinite warmed likelihood value")
print(json.dumps({
    "fit_id": args.case, "backend": jax.default_backend(), "device": jax.devices()[0].device_kind,
    "jax_version": jax.__version__, "startup_seconds": startup, "calls": args.calls,
    "warm_median_seconds": float(np.median(durations)), "warm_mean_seconds": float(np.mean(durations)),
    "warm_p90_seconds": float(np.quantile(durations,.9)), "truth_loglike": truth_value,
    "reference_truth_loglike": reference, "observations_shape": list(arrays["data/obs_csd_star"].shape),
    "response_shape": list(arrays["tables/response"].shape),
}, indent=2))
