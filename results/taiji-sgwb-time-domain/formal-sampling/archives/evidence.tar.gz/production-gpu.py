"""Run or resume the unchanged formal FD Figure 8 inference on CUDA."""
import json
from pathlib import Path
import runpy
import subprocess
import sys
import time

import dill

base = Path(__file__).resolve().parent
campaign = runpy.run_path(str(base / "fd-campaign.py"))
logs = base / "logs"
report_path = logs / "fd-campaign.json"
report = json.loads(report_path.read_text())
checkpoint = base / "pilot/fit_079/fit_079_resume.pickle"
with checkpoint.open("rb") as stream:
    pilot = dill.load(stream)
restart = report["pilot_checkpoint"]
if pilot.it <= restart["iteration"] or pilot.ncall <= restart["likelihood_calls"]:
    raise RuntimeError("No increased iteration and call counts in the resumed checkpoint")
if "Resume file successfully loaded." not in (logs/"pilot-resume.txt").read_text(errors="replace"):
    raise RuntimeError("No successful checkpoint reload in the pilot log")
report["pilot_resume_verified"] = {"iteration": int(pilot.it), "likelihood_calls": int(pilot.ncall)}
report.pop("error", None)
report["backend"] = "gpu"
report["status"] = "running"

def save():
    tmp = report_path.with_suffix(".tmp")
    tmp.write_text(json.dumps(report, indent=2)+"\n")
    tmp.replace(report_path)

out = base/"production"
resume = "--resume" in sys.argv[1:]
log_path = logs / ("production-resume.txt" if resume else "production.txt")
runner = ('import os,runpy,sys; sys.path.append(os.environ["CUDA_SITE"]); '
          'sys.argv[0]="infer.py"; runpy.run_path("infer.py",run_name="__main__")')
cmd = [sys.executable,"-u","-c",runner,*campaign["run"][3:],"--output",str(out)]
if resume:
    cmd.append("--resume")
attempt = {"command": cmd, "started_utc_epoch": time.time()}
report.setdefault("production_attempts", []).append(attempt)
report["production"] = attempt
save()
start = time.monotonic()
with log_path.open("wb") as log:
    process = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT)
    attempt["pid"] = process.pid
    save()
    code = process.wait()
attempt.update(returncode=code, wall_seconds=time.monotonic()-start)
report["production_wall_seconds_total"] = sum(x.get("wall_seconds",0) for x in report["production_attempts"])
report["status"] = "paused" if code == 130 else "failed"
save()
if code:
    raise SystemExit(code)
report["production_result"] = campaign["results"](out)
report["status"] = "complete"
save()
