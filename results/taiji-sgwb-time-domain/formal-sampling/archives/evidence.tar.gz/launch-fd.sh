set -euo pipefail
base=/home/disk/sgwb-research/fullcov-fig8-20261121
cd "$base"
exec 9>logs/fd-campaign.lock
flock -n 9
date -u
export JAX_PLATFORMS=cpu MPLBACKEND=Agg MPLCONFIGDIR="$base/matplotlib"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export XLA_PYTHON_CLIENT_PREALLOCATE=false
p="$base/.venv/bin/python"
cd external/taiji-sgwb-time-domain
"$p" -u get_data.py --archive "$base/archive/replay.tar.gz"
"$p" -u scripts/astro/ch33_sw10_fullxyz_20260531.py build-fd-equal --seed 2026060255 --segments 360 --log-omega-0=-11.5
exec nice -n 5 "$p" -u "$base/fd-campaign.py"
